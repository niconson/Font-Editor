//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FontManager.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FONTMATYPE                  129
#define IDD_EDIT_DIALOG                 130
#define IDC_DRAW                        1000
#define IDC_DRAG                        1001
#define IDC_KILL                        1002
#define IDC_DRAG_LINE                   1003
#define IDC_KILL_LINE                   1004
#define IDC_REVERT                      1006
#define IDC_UNDO                        1007
#define IDM_XLATED_VIEW                 32771
#define IDM_ASSIGN                      32772
#define IDM_INDEX                       32773
#define IDM_CLEAR                       32774
#define IDM_WHO_USES                    32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
